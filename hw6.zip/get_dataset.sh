# Untar the faces dataset
wget http://vision.stanford.edu/teaching/cs131_fall1718/files/data/hw6/faces.tar.gz
tar -xzvf faces.tar.gz
